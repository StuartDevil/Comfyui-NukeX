from .nuke_util.nuke_util import get_nuke_path

COMFYUI_DIR = '<path_to_ComfyUI>'
IP = '127.0.0.1'
PORT = 8188
NUKE_USER = get_nuke_path() # /home/<USER>/.nuke
